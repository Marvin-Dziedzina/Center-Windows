Download the zip folder
Extract all files to an directory you want
Double click CW Advanced.exe
CW Advanced should start

buildConfigs.json are for auto-py-to-exe